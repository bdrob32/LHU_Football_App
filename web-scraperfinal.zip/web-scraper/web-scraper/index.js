const PORT = 8000
const axios = require('axios') //Promise based http client for the browser and node.js
const cheerio = require('cheerio') //implementation of jquery and parses data
const express = require('express') //web framework for node js
const cors = require('cors') // middleware for node.js and express
const app = express()
app.use(cors())
//const url = 'https://www.theguardian.com/us'

//app.METHOD(PATH, HANDLER)

/**
app.get() //get data

app.post() //add data

app.put() //edit

app.delete() //delete data
*/

app.get('/', function (req, res) {
    res.json('This is my webscraper')
})

app.get('/results', (req, res) => {

    //Pulls Player Name
    //const url = 'https://www.golhu.com/sports/football/roster'
    // axios(url)
    //    .then(response =>{
    //    const html = response.data
    //        const $ = cheerio.load(html)
    //        const articles = []
    //        $('.sidearm-roster-player-name', html).each(function (){
    //           //const  title = $(this).text()
    //            const title = $(this).find('a').text()
    //            articles.push({
    //                title,
    //             //   url,
    //            })
    //        })
    //        res.json(articles)
    // }).catch(err => console.log(err))



    //})

    //axios(url)
    //    .then(response =>{
    //    const html = response.data
    //        const $ = cheerio.load(html)
    //        const articles = []
    //        $('.fc-item__title', html).each(function (){
    //           const  title = $(this).text()
    //            const url = $(this).find('a').attr('href')
    //            articles.push({
    //                title,
    //                url
    //            })
    //        })
    //        console.log(articles)
    //}).catch(err => console.log(err))


    //app.listen(PORT, () => console.log('server running on PORT ${PORT}'))


    
    const url = 'https://www.espn.com/college-football/team/schedule/_/id/209/season/2022'

    axios(url)
        .then(response => {
            const html = response.data
            const $ = cheerio.load(html)
            const articles = []
            const $p = $('.Table__TR.Table__TR--sm.Table__even')
            $($p, html).each(function () {
                const team = $(this).find('div span').text()
                const result1 = $(this).find('span.fw-bold.clr-positive').text()
                const result2 = $(this).find('span.fw-bold.clr-negative').text()

                //return team.text().join(' ')
                const score = $(this).find('.ml4').text()
                const url = $(this).find('a').attr('href')
                if (url != null)
                articles.push({
                    team,
                    result1,
                    result2,
                    score,
                    url
                })
            })
            console.log(articles)
            res.json(articles)
        }).catch(err => console.log(err))
 })

app.listen(PORT, () => console.log(`server running on PORT ${PORT}`))

