CREATE OR REPLACE TABLE ATHLETE (
  playerName      VARCHAR(32),
  team            VARCHAR(32),
  classYear       CHAR(32),
  playerPosition  CHAR(32),
  playerHeight    VARCHAR(32),
  playerWeight    int(3),
  major           CHAR(32),
  hometown        CHAR(32),
  playerNumber    int(2),
  PRIMARY KEY (playerNumber),
  FOREIGN KEY (playerName) REFERENCES ATHLETE_STATS(playerName)
);
CREATE DATABASE rbt2310_LHUFootball
;
INSERT INTO ATHLETE VALUES('Marquon Williams','Football','Sophomore','Wide Receiver','6.2','190','Sports Management','Kenosha Wi','3');
INSERT INTO ATHLETE VALUES('Darryl Pollard','Football','Sophomore','Defensive Back','5.10','185','Sports Management','Philadelphia Pa','4');


CREATE TABLE ATHLETE_STATS (
  playerName        VARCHAR(32),
  rushingYards      INT(4),
  recievingYards    INT(4),
  touchdowns        INT(3),
  tackles           INT(3),
  sacks             INT(3),
  interceptions     INT(3),
  gamesPlayed       INT(2),
  feildgoals        INT(3),
  PRIMARY KEY (playerName)
);

INSERT INTO ATHLETE_STATS VALUES('Marquon Williams','16','600','7','3','0','0','5','0');
INSERT INTO ATHLETE_STATS VALUES('Darryl Pollard','0','0','0','45','0','0','9','0');


CREATE or Replace TABLE TEAM_SCHEDULE (
  gameId          INT(2),
  opponent        CHAR(32),
  game_date       VARCHAR(32),
  game_location   CHAR(32),
  game_time       TIME,
  finalScore      VARCHAR(5),
  winner          CHAR(32),
  PRIMARY KEY (gameId)
);
INSERT INTO ATHLETE VALUES('1','Post','2022-8-3','Away','13:00:00','35-34','LHU');



--sus
CREATE TABLE RESULTS (
  gameId          INT(2),
  LHUPoints1      INT(2),
  OPPPoints2      CHAR(32),
  finalScore      TIME,
  PRIMARY KEY (gameId), 
  FOREIGN KEY (finalScore) REFERENCES TEAM_SCHEDULE(finalScore)
);
INSERT INTO ATHLETE VALUES('Marquon Williams','Football','Sophomore','Wide Receiver','6.2','190','Sports Management','Kenosha Wi','3');
